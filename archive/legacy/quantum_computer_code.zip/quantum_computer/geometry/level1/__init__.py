"""Level 1: Geometry in geometry."""

