"""Level 2: Geometry in geometry in geometry."""

