"""Hierarchical geometry system."""

