"""Level 0: Base geometry."""

