"""
Quantum Computer: Hierarchical Geometry System

Principle: Geometry > Geometry in Geometry
"""

__version__ = "1.0.0"

