"""Core quantum operations."""

